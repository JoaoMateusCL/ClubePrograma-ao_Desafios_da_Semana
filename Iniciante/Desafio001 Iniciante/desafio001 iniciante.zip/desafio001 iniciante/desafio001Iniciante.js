const entrada = require('prompt-sync')({sigint: true}) //chamando uma "função" de entrada no javaScript

let numeroAleatorio = Math.floor(Math.random()*100) //Criando números Aleatórios
let palpiteDoUsuario = 0

console.log("Jogo da Adivinhação: \nAdivinhe o número que está entre 0 e 100") //Apresentação do jogo

//Bloco para o código repitir enquanto o usuário não acertar o número
while(palpiteDoUsuario!=numeroAleatorio)
{
    palpiteDoUsuario = entrada("Digite o seu palpite: ")//Entrada do palpite do usuário

    //Bloco que serve para comparar o palpite do usuario com o número aleatório
    if(palpiteDoUsuario < numeroAleatorio)
    {
        console.log(`O número é maior!!`)   
    }
    else if(palpiteDoUsuario > numeroAleatorio)
    {
        console.log(`O número é menor!!`)
    }
    else
    {
        console.log(`Você acertou!! o número certo era ${numeroAleatorio}`)
    }
}